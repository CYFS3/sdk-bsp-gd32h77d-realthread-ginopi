/**
 * @file lv_demo_music.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "lv_demo_rtt_music.h"

#if LV_USE_DEMO_RTT_MUSIC

#if LVGL_VERSION_MAJOR >= 9 && LV_COLOR_DEPTH == 16
#include "image/lv_image_decoder_private.h"
#endif

#include "lv_demo_rtt_music_main.h"
#include "lv_demo_rtt_music_list.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
#if LVGL_VERSION_MAJOR >= 9 && LV_COLOR_DEPTH == 16
static void legacy_alpha_decoder_init(void);
static bool legacy_alpha_image_check(const lv_image_dsc_t * image);
static lv_result_t legacy_alpha_decoder_info(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc,
                                             lv_image_header_t * header);
static lv_result_t legacy_alpha_decoder_open(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc);
static void legacy_alpha_decoder_close(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc);
#endif

#if LV_DEMO_RTT_MUSIC_AUTO_PLAY
static void auto_step_cb(lv_timer_t * timer);
#endif

/**********************
 *  STATIC VARIABLES
 **********************/
static lv_obj_t * ctrl;
static lv_obj_t * list;

#if LVGL_VERSION_MAJOR >= 9 && LV_COLOR_DEPTH == 16
static lv_image_decoder_t * legacy_alpha_decoder;
#endif

static const char * title_list[] = {
    "Waiting for true love",
    "Need a Better Future",
    "Vibrations",
    "Why now?",
    "Never Look Back",
    "It happened Yesterday",
    "Feeling so High",
    "Go Deeper",
    "Find You There",
    "Until the End",
    "Unknown",
    "Unknown",
    "Unknown",
    "Unknown",
};

static const char * artist_list[] = {
    "The John Smith Band",
    "My True Name",
    "Robotics",
    "John Smith",
    "My True Name",
    "Robotics",
    "Robotics",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
    "Unknown artist",
};

static const char * genre_list[] = {
    "Rock - 1997",
    "Drum'n bass - 2016",
    "Psy trance - 2020",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
    "Metal - 2015",
};

static const uint32_t time_list[] = {
    1 * 60 + 14,
    2 * 60 + 26,
    1 * 60 + 54,
    2 * 60 + 24,
    2 * 60 + 37,
    3 * 60 + 33,
    1 * 60 + 56,
    3 * 60 + 31,
    2 * 60 + 20,
    2 * 60 + 19,
    2 * 60 + 20,
    2 * 60 + 19,
    2 * 60 + 20,
    2 * 60 + 19,
};

#if LV_DEMO_RTT_MUSIC_AUTO_PLAY
    static lv_timer_t * auto_step_timer;
#endif

static lv_color_t original_screen_bg_color;

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

void lv_demo_music(void)
{
#if LVGL_VERSION_MAJOR >= 9 && LV_COLOR_DEPTH == 16
    legacy_alpha_decoder_init();
#endif

    original_screen_bg_color = lv_obj_get_style_bg_color(lv_scr_act(), 0);
    lv_obj_set_style_bg_color(lv_scr_act(), lv_color_hex(0x343247), 0);

    list = _lv_demo_music_list_create(lv_scr_act());
    ctrl = _lv_demo_music_main_create(lv_scr_act());

#if LV_DEMO_RTT_MUSIC_AUTO_PLAY
    auto_step_timer = lv_timer_create(auto_step_cb, 1000, NULL);
#endif
}

void lv_demo_music_close(void)
{
    /*Delete all aniamtions*/
    lv_anim_del(NULL, NULL);

#if LV_DEMO_RTT_MUSIC_AUTO_PLAY
    lv_timer_del(auto_step_timer);
#endif
    _lv_demo_music_list_close();
    _lv_demo_music_main_close();

    lv_obj_clean(lv_scr_act());

    lv_obj_set_style_bg_color(lv_scr_act(), original_screen_bg_color, 0);
}

const char * _lv_demo_music_get_title(uint32_t track_id)
{
    if(track_id >= sizeof(title_list) / sizeof(title_list[0])) return NULL;
    return title_list[track_id];
}

const char * _lv_demo_music_get_artist(uint32_t track_id)
{
    if(track_id >= sizeof(artist_list) / sizeof(artist_list[0])) return NULL;
    return artist_list[track_id];
}

const char * _lv_demo_music_get_genre(uint32_t track_id)
{
    if(track_id >= sizeof(genre_list) / sizeof(genre_list[0])) return NULL;
    return genre_list[track_id];
}

uint32_t _lv_demo_music_get_track_length(uint32_t track_id)
{
    if(track_id >= sizeof(time_list) / sizeof(time_list[0])) return 0;
    return time_list[track_id];
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

#if LVGL_VERSION_MAJOR >= 9 && LV_COLOR_DEPTH == 16
static void legacy_alpha_decoder_init(void)
{
    if(legacy_alpha_decoder != NULL) return;

    legacy_alpha_decoder = lv_image_decoder_create();
    if(legacy_alpha_decoder == NULL) {
        LV_LOG_WARN("Failed to create the music demo legacy alpha decoder");
        return;
    }

    lv_image_decoder_set_info_cb(legacy_alpha_decoder, legacy_alpha_decoder_info);
    lv_image_decoder_set_open_cb(legacy_alpha_decoder, legacy_alpha_decoder_open);
    lv_image_decoder_set_close_cb(legacy_alpha_decoder, legacy_alpha_decoder_close);
    legacy_alpha_decoder->name = "RTT music alpha";
}

static bool legacy_alpha_image_check(const lv_image_dsc_t * image)
{
    if(image == NULL || image->data == NULL) return false;
    if(image->header.magic != LV_IMAGE_HEADER_LEGACY) return false;
    if(image->header.cf != LV_COLOR_FORMAT_RGB565A8) return false;
    if(image->header.stride != 0) return false;

    uint32_t expected_size = image->header.w * image->header.h * 3;
    return image->data_size == expected_size;
}

static lv_result_t legacy_alpha_decoder_info(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc,
                                             lv_image_header_t * header)
{
    LV_UNUSED(decoder);

    if(dsc == NULL || header == NULL || dsc->src_type != LV_IMAGE_SRC_VARIABLE) return LV_RESULT_INVALID;

    const lv_image_dsc_t * image = dsc->src;
    if(!legacy_alpha_image_check(image)) return LV_RESULT_INVALID;

    lv_memcpy(header, &image->header, sizeof(*header));
    header->magic = LV_IMAGE_HEADER_MAGIC;
    header->cf = LV_COLOR_FORMAT_RGB565A8;
    header->stride = image->header.w * 2;
    header->flags &= ~LV_IMAGE_FLAGS_PREMULTIPLIED;

    return LV_RESULT_OK;
}

static lv_result_t legacy_alpha_decoder_open(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc)
{
    LV_UNUSED(decoder);

    if(dsc == NULL || dsc->src_type != LV_IMAGE_SRC_VARIABLE) return LV_RESULT_INVALID;

    const lv_image_dsc_t * image = dsc->src;
    if(!legacy_alpha_image_check(image)) return LV_RESULT_INVALID;

    uint32_t w = image->header.w;
    uint32_t h = image->header.h;
    uint32_t rgb_stride = w * 2;
    lv_draw_buf_t * decoded = lv_draw_buf_create(w, h, LV_COLOR_FORMAT_RGB565A8, rgb_stride);
    if(decoded == NULL) return LV_RESULT_INVALID;

    const uint8_t * src = image->data;
    uint8_t * rgb = decoded->data;
    uint8_t * alpha = decoded->data + rgb_stride * h;

    for(uint32_t y = 0; y < h; y++) {
        uint8_t * rgb_row = rgb + y * rgb_stride;
        uint8_t * alpha_row = alpha + y * w;

        for(uint32_t x = 0; x < w; x++) {
            rgb_row[x * 2] = src[0];
            rgb_row[x * 2 + 1] = src[1];
            alpha_row[x] = src[2];
            src += 3;
        }
    }

    dsc->header.magic = LV_IMAGE_HEADER_MAGIC;
    dsc->header.cf = LV_COLOR_FORMAT_RGB565A8;
    dsc->header.w = w;
    dsc->header.h = h;
    dsc->header.stride = rgb_stride;
    dsc->decoded = decoded;
    dsc->user_data = decoded;
    dsc->args.no_cache = true;

    return LV_RESULT_OK;
}

static void legacy_alpha_decoder_close(lv_image_decoder_t * decoder, lv_image_decoder_dsc_t * dsc)
{
    LV_UNUSED(decoder);

    if(dsc == NULL || dsc->user_data == NULL) return;

    lv_draw_buf_destroy((lv_draw_buf_t *)dsc->user_data);
    dsc->user_data = NULL;
    dsc->decoded = NULL;
}
#endif

#if LV_DEMO_RTT_MUSIC_AUTO_PLAY
static void auto_step_cb(lv_timer_t * t)
{
    LV_UNUSED(t);
    static uint32_t state = 0;

#if LV_DEMO_RTT_MUSIC_LARGE
    // const lv_font_t * font_small = &lv_font_montserrat_22;
    const lv_font_t * font_large = &lv_font_montserrat_32;
#else
    // const lv_font_t * font_small = &lv_font_montserrat_12;
    const lv_font_t * font_large = &lv_font_montserrat_16;
#endif

    switch(state) {
    case 5:
        _lv_demo_music_album_next(true);
        break;

    case 6:
        _lv_demo_music_album_next(true);
        break;
    case 7:
        _lv_demo_music_album_next(true);
        break;
    case 8:
        _lv_demo_music_play(0);
        break;
#if LV_DEMO_RTT_MUSIC_SQUARE || LV_DEMO_RTT_MUSIC_ROUND
    case 11:
        lv_obj_scroll_by(ctrl, 0, -LV_VER_RES, LV_ANIM_ON);
        break;
    case 13:
        lv_obj_scroll_by(ctrl, 0, -LV_VER_RES, LV_ANIM_ON);
        break;
#else
    case 12:
        lv_obj_scroll_by(ctrl, 0, -LV_VER_RES, LV_ANIM_ON);
        break;
#endif
    case 15:
        lv_obj_scroll_by(list, 0, -300, LV_ANIM_ON);
        break;
    case 16:
        lv_obj_scroll_by(list, 0, 300, LV_ANIM_ON);
        break;
    case 18:
        _lv_demo_music_play(1);
        break;
    case 19:
        lv_obj_scroll_by(ctrl, 0, LV_VER_RES, LV_ANIM_ON);
        break;
#if LV_DEMO_RTT_MUSIC_SQUARE || LV_DEMO_RTT_MUSIC_ROUND
    case 20:
        lv_obj_scroll_by(ctrl, 0, LV_VER_RES, LV_ANIM_ON);
        break;
#endif
    case 30:
        _lv_demo_music_play(2);
        break;
#ifndef LV_DEMO_RTT_MUSIC_AUTO_PLAY_FOREVER
    case 40: {
          lv_obj_t * bg = lv_layer_top();
          lv_obj_set_style_bg_color(bg, lv_color_hex(0x28B8BA), 0);
          lv_obj_set_style_text_color(bg, lv_color_white(), 0);
          lv_obj_set_style_bg_opa(bg, LV_OPA_COVER, 0);
          lv_obj_fade_in(bg, 400, 0);
          lv_obj_t * dsc = lv_label_create(bg);
          lv_obj_set_style_text_font(dsc, font_large, 0);
          lv_label_set_text(dsc, "The average FPS is");
          lv_obj_align(dsc, LV_ALIGN_TOP_MID, 0, 200);

          lv_obj_t * num = lv_label_create(bg);
          lv_obj_set_style_text_font(num, font_large, 0);
#if LV_USE_PERF_MONITOR
          lv_label_set_text_fmt(num, "%"LV_PRId32, lv_refr_get_fps_avg());
#endif
          lv_obj_align(num, LV_ALIGN_TOP_MID, 0, 230);

          /* show LVGL and RT-Thread version */
          lv_obj_t* version_attr = lv_label_create(bg);
          lv_obj_set_style_text_align(version_attr, LV_TEXT_ALIGN_CENTER, 0);
          lv_obj_set_style_text_font(version_attr, font_large, 0);
          lv_label_set_text_fmt(version_attr, "LVGL %"LV_PRIu32".%"LV_PRIu32".%"LV_PRIu32" & RT-Thread %"LV_PRIu32".%"LV_PRIu32".%"LV_PRIu32,
              (uint32_t)LVGL_VERSION_MAJOR, (uint32_t)LVGL_VERSION_MINOR, (uint32_t)LVGL_VERSION_PATCH,
#if RT_VER_NUM < 0x50000
              (uint32_t)RT_VERSION, (uint32_t)RT_SUBVERSION, (uint32_t)RT_REVISION);
#else
              (uint32_t)RT_VERSION_MAJOR, (uint32_t)RT_VERSION_MINOR, (uint32_t)RT_VERSION_PATCH);
#endif
          lv_obj_align(version_attr, LV_ALIGN_BOTTOM_MID, 0, -70);

          /* show LVGL copyright */
          lv_obj_t * lvgl_copyright_attr = lv_label_create(bg);
          lv_obj_set_style_text_align(lvgl_copyright_attr, LV_TEXT_ALIGN_CENTER, 0);
          lv_obj_set_style_text_font(lvgl_copyright_attr, font_large, 0);
#if LV_DEMO_RTT_MUSIC_SQUARE || LV_DEMO_RTT_MUSIC_ROUND
          lv_label_set_text(lvgl_copyright_attr, "Copyright 2022 LVGL Kft.\nwww.lvgl.io | lvgl@lvgl.io");
#else
          lv_label_set_text(lvgl_copyright_attr, "Copyright 2022 LVGL Kft. | www.lvgl.io | lvgl@lvgl.io");
#endif
          lv_obj_align(lvgl_copyright_attr, LV_ALIGN_BOTTOM_MID, 0, -40);

          /* show RT-Thread copyright */
          lv_obj_t * rtt_copyright_attr = lv_label_create(bg);
          lv_obj_set_style_text_align(rtt_copyright_attr, LV_TEXT_ALIGN_CENTER, 0);
          lv_obj_set_style_text_font(rtt_copyright_attr, font_large, 0);
          lv_label_set_text(rtt_copyright_attr, "RT-Thread IoT RTOS | www.rt-thread.io");
          lv_obj_align(rtt_copyright_attr, LV_ALIGN_BOTTOM_MID, 0, -10);
          break;
    }
#endif /* LV_DEMO_RTT_MUSIC_AUTO_PLAY_FOREVER */
    case 41:
#ifndef LV_DEMO_RTT_MUSIC_AUTO_PLAY_FOREVER
        lv_scr_load(lv_obj_create(NULL));
        _lv_demo_music_pause();
#else
        state = 0;
#endif
        break;
    }
    state++;
}

#endif /*LV_DEMO_RTT_MUSIC_AUTO_PLAY*/

#endif /*LV_USE_DEMO_RTT_MUSIC*/
