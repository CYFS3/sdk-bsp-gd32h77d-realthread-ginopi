/**
 * @file lv_demo_rtt_music.h
 *
 */

#ifndef LV_DEMO_RTT_MUSIC_H
#define LV_DEMO_RTT_MUSIC_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include <lvgl.h>

#if LVGL_VERSION_MAJOR >= 9
#ifndef LV_IMG_ZOOM_NONE
#define LV_IMG_ZOOM_NONE LV_SCALE_NONE
#endif
#ifndef LV_COLOR_SIZE
#define LV_COLOR_SIZE LV_COLOR_DEPTH
#endif
#ifndef LV_IMG_PX_SIZE_ALPHA_BYTE
#define LV_IMG_PX_SIZE_ALPHA_BYTE (LV_COLOR_DEPTH / 8 + 1)
#endif
#ifndef LV_IMG_CF_TRUE_COLOR
#define LV_IMG_CF_TRUE_COLOR LV_COLOR_FORMAT_NATIVE
#endif
#ifndef LV_IMG_CF_TRUE_COLOR_ALPHA
#define LV_IMG_CF_TRUE_COLOR_ALPHA LV_COLOR_FORMAT_NATIVE_WITH_ALPHA
#endif
#ifndef lv_obj_del_anim_ready_cb
#define lv_obj_del_anim_ready_cb lv_obj_delete_anim_completed_cb
#endif
#ifndef always_zero
#define always_zero magic
#endif
#endif

#if LV_USE_DEMO_RTT_MUSIC

/*********************
 *      DEFINES
 *********************/

#if LV_DEMO_RTT_MUSIC_LARGE
#  define LV_DEMO_MUSIC_HANDLE_SIZE  40
#else
#  define LV_DEMO_MUSIC_HANDLE_SIZE  20
#endif

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 * GLOBAL PROTOTYPES
 **********************/

void lv_demo_music(void);
void lv_demo_music_close(void);
const char * _lv_demo_music_get_title(uint32_t track_id);
const char * _lv_demo_music_get_artist(uint32_t track_id);
const char * _lv_demo_music_get_genre(uint32_t track_id);
uint32_t _lv_demo_music_get_track_length(uint32_t track_id);

/**********************
 *      MACROS
 **********************/

#endif /*LV_USE_DEMO_RTT_MUSIC*/

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /*LV_DEMO_RTT_MUSIC_H*/
