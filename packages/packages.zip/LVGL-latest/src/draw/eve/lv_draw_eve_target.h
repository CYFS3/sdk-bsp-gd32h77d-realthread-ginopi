#warning Include public headers from the `src` folder is deprecated. This file will be removed soon. To ensure your application keeps working, you can choose to include the new header in <include/lvgl/drivers/display/lv_draw_eve_target.h> or include the main header file <include/lvgl/lvgl.h>
#include "../../../include/lvgl/lvgl.h"
