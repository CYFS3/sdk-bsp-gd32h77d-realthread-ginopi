#warning Include public headers from the `src` folder is deprecated. This file will be removed soon. To ensure your application keeps working, you can choose to include the new header in <include/lvgl/draw/lv_draw_triangle.h> or include the main header file <include/lvgl/lvgl.h>
#include "../../include/lvgl/lvgl.h"
