/**
 * @file lv_tabview.h
 *
 */

#ifndef LV_TABVIEW_H
#define LV_TABVIEW_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "../config/lv_conf_internal.h"
#include "../core/lv_obj.h"
#include "../core/lv_obj_property.h"

#if LV_USE_TABVIEW

/*********************
 *      DEFINES
 *********************/

LV_ATTRIBUTE_EXTERN_DATA extern const lv_obj_class_t lv_tabview_class;

#if LV_USE_OBJ_PROPERTY
enum _lv_property_tabview_id_t {
    LV_PROPERTY_ID(TABVIEW, TAB_ACTIVE,       LV_PROPERTY_TYPE_INT, 0),
    LV_PROPERTY_ID(TABVIEW, TAB_BAR_POSITION, LV_PROPERTY_TYPE_INT, 1),
    LV_PROPERTY_TABVIEW_END,
};
#endif

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**
 * Create a tabview widget
 * @param parent    pointer to a parent widget @nullable. When NULL, the widget
 *                  is created as a screen on the default display.
 * @return          the created tabview
 */
lv_obj_t * lv_tabview_create(lv_obj_t * parent);

/**
 * Add a tab to the tabview
 * @param obj       pointer to a tabview widget
 * @param name      the name of the tab, it will be displayed on the tab bar @nullable
 *                  When NULL the tab button's label keeps the default label text
 *                  (`LV_LABEL_DEFAULT_TEXT`). Useful when the text is set later,
 *                  e.g. via a translation tag.
 * @return          the widget where the content of the tab can be created
 */
lv_obj_t * lv_tabview_add_tab(lv_obj_t * obj, const char * name);

/**
 * Change the name of the tab
 * @param obj       pointer to a tabview widget
 * @param idx       the index of the tab to rename
 * @param new_name  the new name as a string @nullable
 *                  When NULL the current name is kept and only refreshed,
 *                  see @ref lv_label_set_text.
 */
void lv_tabview_set_tab_text(lv_obj_t * obj, uint32_t idx, const char * new_name);

#if LV_USE_TRANSLATION

/**
 * Add a tab to the tabview whose label is bound to a translation tag.
 * The tab bar shows the translation of @p tag for the currently selected language,
 * and updates automatically on `lv_translation_set_language()`.
 * If no language is selected or the tag is not found in any translation pack,
 * the tag itself is displayed.
 * @param obj       pointer to a tabview widget
 * @param tag       '\0' terminated translation key, must be non-NULL and not empty.
 * @return          the widget where the content of the tab can be created
 */
lv_obj_t * lv_tabview_set_tab_translation_tag(lv_obj_t * obj, const char * tag);

#endif

/**
 * Show a tab
 * @param obj       pointer to a tabview widget
 * @param idx       the index of the tab to show
 * @param anim_en   LV_ANIM_ON/OFF
 */
void lv_tabview_set_active(lv_obj_t * obj, uint32_t idx, lv_anim_enable_t anim_en);

/**
 * Set the position of the tab bar
 * @param obj       pointer to a tabview widget
 * @param dir       LV_DIR_TOP/BOTTOM/LEFT/RIGHT
 */
void lv_tabview_set_tab_bar_position(lv_obj_t * obj, lv_dir_t dir);

/**
 * Set the width or height of the tab bar
 * @param obj       pointer to tabview widget
 * @param size      size of the tab bar in pixels or percentage.
 *                  will be used as width or height based on the position of the tab bar)
 */
void lv_tabview_set_tab_bar_size(lv_obj_t * obj, int32_t size);

/**
 * Get the number of tabs
 * @param obj       pointer to a tabview widget
 * @return          the number of tabs
 */
uint32_t lv_tabview_get_tab_count(lv_obj_t * obj);

/**
 * Get the current tab's index
 * @param obj       pointer to a tabview widget
 * @return          the zero based index of the current tab
 */
uint32_t lv_tabview_get_tab_active(lv_obj_t * obj);

/**
 * Get a given tab button by index
 * @param obj       pointer to a tabview widget
 * @param idx       zero based index of the tab button to get.
 *                  < 0 means start counting tab button from the back (-1 is the last tab button)
 * @return          pointer to the tab button, or NULL if the index was out of range
 */
lv_obj_t * lv_tabview_get_tab_button(lv_obj_t * obj, int32_t idx);

/**
 * Get the widget where the container of each tab is created
 * @param obj       pointer to a tabview widget
 * @return          the main container widget
 */
lv_obj_t * lv_tabview_get_content(lv_obj_t * obj);

/**
 * Get the tab bar where the buttons are created
 * @param obj       pointer to a tabview widget
 * @return          the tab bar
 */
lv_obj_t * lv_tabview_get_tab_bar(lv_obj_t * obj);

/**
 * Get the position of the tab bar
 * @param obj       pointer to a tabview widget
 * @return          LV_DIR_TOP/BOTTOM/LEFT/RIGHT
 */
lv_dir_t lv_tabview_get_tab_bar_position(lv_obj_t * obj);

/**********************
 *      MACROS
 **********************/

#endif /*LV_USE_TABVIEW*/

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*LV_TABVIEW_H*/
