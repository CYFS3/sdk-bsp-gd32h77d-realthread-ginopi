/**
 * @file lv_obj.h
 *
 */

#ifndef LV_OBJ_H
#define LV_OBJ_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "../config/lv_conf_internal.h"

#include "../lv_types.h"
#include "lv_style.h"
#include "lv_area.h"
#include "../draw/lv_color.h"
#include "../debugging/lv_assert.h"

#include "lv_obj_tree.h"
#include "lv_obj_pos.h"
#include "lv_obj_scroll.h"
#include "lv_obj_style.h"
#include "lv_obj_draw.h"
#include "lv_obj_class.h"
#include "lv_obj_event.h"
#include "lv_obj_property.h"
#include "lv_group.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

typedef void(*lv_delete_cb_t)(void * user_data);

/**
 * On/Off features controlling the object's behavior.
 * OR-ed values are possible
 *
 * Note: update obj flags corresponding properties below
 * whenever add/remove flags or change bit definition of flags.
 */
typedef enum {
    LV_OBJ_FLAG_HIDDEN          = (1u << 0),  /**< Make the object hidden. (Like it wasn't there at all)*/
    LV_OBJ_FLAG_CLICKABLE       = (1u << 1),  /**< Make the object clickable by the input devices*/
    LV_OBJ_FLAG_CLICK_FOCUSABLE = (1u << 2),  /**< Add focused state to the object when clicked*/
    LV_OBJ_FLAG_CHECKABLE       = (1u << 3),  /**< Toggle checked state when the object is clicked*/
    LV_OBJ_FLAG_SCROLLABLE      = (1u << 4),  /**< Make the object scrollable*/
    LV_OBJ_FLAG_SCROLL_ELASTIC  = (1u << 5),  /**< Allow scrolling inside but with slower speed*/
    LV_OBJ_FLAG_SCROLL_MOMENTUM = (1u << 6),  /**< Make the object scroll further when "thrown"*/
    LV_OBJ_FLAG_SCROLL_ONE      = (1u << 7),  /**< Allow scrolling only one snappable children*/
    LV_OBJ_FLAG_SCROLL_CHAIN_HOR = (1u << 8), /**< Allow propagating the horizontal scroll to a parent*/
    LV_OBJ_FLAG_SCROLL_CHAIN_VER = (1u << 9), /**< Allow propagating the vertical scroll to a parent*/
    LV_OBJ_FLAG_SCROLL_CHAIN     = (LV_OBJ_FLAG_SCROLL_CHAIN_HOR | LV_OBJ_FLAG_SCROLL_CHAIN_VER),
    LV_OBJ_FLAG_SCROLL_ON_FOCUS = (1u << 10),  /**< Automatically scroll object to make it visible when focused*/
    LV_OBJ_FLAG_SCROLL_WITH_ARROW  = (1u << 11), /**< Allow scrolling the focused object with arrow keys*/
    LV_OBJ_FLAG_SNAPPABLE       = (1u << 12), /**< If scroll snap is enabled on the parent it can snap to this object*/
    LV_OBJ_FLAG_PRESS_LOCK      = (1u << 13), /**< Keep the object pressed even if the press slid from the object*/
    LV_OBJ_FLAG_EVENT_BUBBLE    = (1u << 14), /**< Propagate the events to the parent too*/
    LV_OBJ_FLAG_GESTURE_BUBBLE  = (1u << 15), /**< Propagate the gestures to the parent*/
    LV_OBJ_FLAG_ADV_HITTEST     = (1u << 16), /**< Allow performing more accurate hit (click) test. E.g. consider rounded corners.*/
    LV_OBJ_FLAG_IGNORE_LAYOUT   = (1u << 17), /**< Make the object not positioned by the layouts*/
    LV_OBJ_FLAG_FLOATING        = (1u << 18), /**< Do not scroll the object when the parent scrolls and ignore layout*/
    LV_OBJ_FLAG_SEND_DRAW_TASK_EVENTS = (1u << 19), /**< Send `LV_EVENT_DRAW_TASK_ADDED` events*/
    LV_OBJ_FLAG_OVERFLOW_VISIBLE = (1u << 20),/**< Do not clip the children to the parent's ext draw size*/
    LV_OBJ_FLAG_EVENT_TRICKLE   = (1u << 21), /**< Propagate the events to the children too*/
    LV_OBJ_FLAG_STATE_TRICKLE   = (1u << 22), /**< Propagate the states to the children too*/

    LV_OBJ_FLAG_LAYOUT_1        = (1u << 23), /**< Custom flag, free to use by layouts*/
    LV_OBJ_FLAG_LAYOUT_2        = (1u << 24), /**< Custom flag, free to use by layouts*/
#if LV_USE_FLEX
    LV_OBJ_FLAG_FLEX_IN_NEW_TRACK = LV_OBJ_FLAG_LAYOUT_1,     /**< Start a new flex track on this item*/
#endif

    LV_OBJ_FLAG_WIDGET_1        = (1u << 25), /**< Custom flag, free to use by widget*/
    LV_OBJ_FLAG_WIDGET_2        = (1u << 26), /**< Custom flag, free to use by widget*/
    LV_OBJ_FLAG_USER_1          = (1u << 27), /**< Custom flag, free to use by user*/
    LV_OBJ_FLAG_USER_2          = (1u << 28), /**< Custom flag, free to use by user*/
    LV_OBJ_FLAG_USER_3          = (1u << 29), /**< Custom flag, free to use by user*/
    LV_OBJ_FLAG_USER_4          = (1u << 30), /**< Custom flag, free to use by user*/
} lv_obj_flag_t;

#if LV_USE_OBJ_PROPERTY
enum _lv_signed_prop_id_t {
    /*OBJ flag properties */
    LV_PROPERTY_ID(OBJ, FLAG_START,                 LV_PROPERTY_TYPE_INT,       0),
    LV_PROPERTY_ID(OBJ, FLAG_HIDDEN,                LV_PROPERTY_TYPE_INT,       0),
    LV_PROPERTY_ID(OBJ, FLAG_CLICKABLE,             LV_PROPERTY_TYPE_INT,       1),
    LV_PROPERTY_ID(OBJ, FLAG_CLICK_FOCUSABLE,       LV_PROPERTY_TYPE_INT,       2),
    LV_PROPERTY_ID(OBJ, FLAG_CHECKABLE,             LV_PROPERTY_TYPE_INT,       3),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLLABLE,            LV_PROPERTY_TYPE_INT,       4),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_ELASTIC,        LV_PROPERTY_TYPE_INT,       5),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_MOMENTUM,       LV_PROPERTY_TYPE_INT,       6),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_ONE,            LV_PROPERTY_TYPE_INT,       7),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_CHAIN_HOR,      LV_PROPERTY_TYPE_INT,       8),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_CHAIN_VER,      LV_PROPERTY_TYPE_INT,       9),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_ON_FOCUS,       LV_PROPERTY_TYPE_INT,       10),
    LV_PROPERTY_ID(OBJ, FLAG_SCROLL_WITH_ARROW,     LV_PROPERTY_TYPE_INT,       11),
    LV_PROPERTY_ID(OBJ, FLAG_SNAPPABLE,             LV_PROPERTY_TYPE_INT,       12),
    LV_PROPERTY_ID(OBJ, FLAG_PRESS_LOCK,            LV_PROPERTY_TYPE_INT,       13),
    LV_PROPERTY_ID(OBJ, FLAG_EVENT_BUBBLE,          LV_PROPERTY_TYPE_INT,       14),
    LV_PROPERTY_ID(OBJ, FLAG_GESTURE_BUBBLE,        LV_PROPERTY_TYPE_INT,       15),
    LV_PROPERTY_ID(OBJ, FLAG_ADV_HITTEST,           LV_PROPERTY_TYPE_INT,       16),
    LV_PROPERTY_ID(OBJ, FLAG_IGNORE_LAYOUT,         LV_PROPERTY_TYPE_INT,       17),
    LV_PROPERTY_ID(OBJ, FLAG_FLOATING,              LV_PROPERTY_TYPE_INT,       18),
    LV_PROPERTY_ID(OBJ, FLAG_SEND_DRAW_TASK_EVENTS, LV_PROPERTY_TYPE_INT,       19),
    LV_PROPERTY_ID(OBJ, FLAG_OVERFLOW_VISIBLE,      LV_PROPERTY_TYPE_INT,       20),
    LV_PROPERTY_ID(OBJ, FLAG_EVENT_TRICKLE,         LV_PROPERTY_TYPE_INT,       21),
    LV_PROPERTY_ID(OBJ, FLAG_STATE_TRICKLE,         LV_PROPERTY_TYPE_INT,       22),
    LV_PROPERTY_ID(OBJ, FLAG_LAYOUT_1,              LV_PROPERTY_TYPE_INT,       23),
    LV_PROPERTY_ID(OBJ, FLAG_LAYOUT_2,              LV_PROPERTY_TYPE_INT,       24),
    LV_PROPERTY_ID(OBJ, FLAG_FLEX_IN_NEW_TRACK,     LV_PROPERTY_TYPE_INT,       23), /*Mapped to FLAG_LAYOUT_1*/
    LV_PROPERTY_ID(OBJ, FLAG_WIDGET_1,              LV_PROPERTY_TYPE_INT,       25),
    LV_PROPERTY_ID(OBJ, FLAG_WIDGET_2,              LV_PROPERTY_TYPE_INT,       26),
    LV_PROPERTY_ID(OBJ, FLAG_USER_1,                LV_PROPERTY_TYPE_INT,       27),
    LV_PROPERTY_ID(OBJ, FLAG_USER_2,                LV_PROPERTY_TYPE_INT,       28),
    LV_PROPERTY_ID(OBJ, FLAG_USER_3,                LV_PROPERTY_TYPE_INT,       29),
    LV_PROPERTY_ID(OBJ, FLAG_USER_4,                LV_PROPERTY_TYPE_INT,       30),
    LV_PROPERTY_ID(OBJ, FLAG_END,                   LV_PROPERTY_TYPE_INT,       30),

    LV_PROPERTY_ID(OBJ, STATE_START,                LV_PROPERTY_TYPE_INT,       31),
    LV_PROPERTY_ID(OBJ, STATE_ALT,                  LV_PROPERTY_TYPE_INT,       31),
    /*1 reserved*/
    LV_PROPERTY_ID(OBJ, STATE_CHECKED,              LV_PROPERTY_TYPE_INT,       33),
    LV_PROPERTY_ID(OBJ, STATE_FOCUSED,              LV_PROPERTY_TYPE_INT,       34),
    LV_PROPERTY_ID(OBJ, STATE_FOCUS_KEY,            LV_PROPERTY_TYPE_INT,       35),
    LV_PROPERTY_ID(OBJ, STATE_EDITED,               LV_PROPERTY_TYPE_INT,       36),
    LV_PROPERTY_ID(OBJ, STATE_HOVERED,              LV_PROPERTY_TYPE_INT,       37),
    LV_PROPERTY_ID(OBJ, STATE_PRESSED,              LV_PROPERTY_TYPE_INT,       38),
    LV_PROPERTY_ID(OBJ, STATE_SCROLLED,             LV_PROPERTY_TYPE_INT,       39),
    LV_PROPERTY_ID(OBJ, STATE_DISABLED,             LV_PROPERTY_TYPE_INT,       40),
    /*2 reserved*/
    LV_PROPERTY_ID(OBJ, STATE_USER_1,               LV_PROPERTY_TYPE_INT,       43),
    LV_PROPERTY_ID(OBJ, STATE_USER_2,               LV_PROPERTY_TYPE_INT,       44),
    LV_PROPERTY_ID(OBJ, STATE_USER_3,               LV_PROPERTY_TYPE_INT,       45),
    LV_PROPERTY_ID(OBJ, STATE_USER_4,               LV_PROPERTY_TYPE_INT,       46),
    LV_PROPERTY_ID(OBJ, STATE_ANY,                  LV_PROPERTY_TYPE_INT,       47),
    LV_PROPERTY_ID(OBJ, STATE_END,                  LV_PROPERTY_TYPE_INT,       47),

    /*OBJ normal properties*/
    LV_PROPERTY_ID(OBJ, PARENT,                     LV_PROPERTY_TYPE_OBJ,       48),
    LV_PROPERTY_ID(OBJ, X,                          LV_PROPERTY_TYPE_INT,       49),
    LV_PROPERTY_ID(OBJ, Y,                          LV_PROPERTY_TYPE_INT,       50),
    LV_PROPERTY_ID(OBJ, W,                          LV_PROPERTY_TYPE_INT,       51),
    LV_PROPERTY_ID(OBJ, H,                          LV_PROPERTY_TYPE_INT,       52),
    LV_PROPERTY_ID(OBJ, CONTENT_WIDTH,              LV_PROPERTY_TYPE_INT,       53),
    LV_PROPERTY_ID(OBJ, CONTENT_HEIGHT,             LV_PROPERTY_TYPE_INT,       54),
    LV_PROPERTY_ID(OBJ, LAYOUT,                     LV_PROPERTY_TYPE_INT,       55),
    LV_PROPERTY_ID(OBJ, ALIGN,                      LV_PROPERTY_TYPE_INT,       56),
    LV_PROPERTY_ID(OBJ, SCROLLBAR_MODE,             LV_PROPERTY_TYPE_INT,       57),
    LV_PROPERTY_ID(OBJ, SCROLL_DIR,                 LV_PROPERTY_TYPE_INT,       58),
    LV_PROPERTY_ID(OBJ, SCROLL_SNAP_X,              LV_PROPERTY_TYPE_INT,       59),
    LV_PROPERTY_ID(OBJ, SCROLL_SNAP_Y,              LV_PROPERTY_TYPE_INT,       60),
    LV_PROPERTY_ID(OBJ, SCROLL_X,                   LV_PROPERTY_TYPE_INT,       61),
    LV_PROPERTY_ID(OBJ, SCROLL_Y,                   LV_PROPERTY_TYPE_INT,       62),
    LV_PROPERTY_ID(OBJ, SCROLL_TOP,                 LV_PROPERTY_TYPE_INT,       63),
    LV_PROPERTY_ID(OBJ, SCROLL_BOTTOM,              LV_PROPERTY_TYPE_INT,       64),
    LV_PROPERTY_ID(OBJ, SCROLL_LEFT,                LV_PROPERTY_TYPE_INT,       65),
    LV_PROPERTY_ID(OBJ, SCROLL_RIGHT,               LV_PROPERTY_TYPE_INT,       66),
    LV_PROPERTY_ID(OBJ, SCROLL_END,                 LV_PROPERTY_TYPE_POINT,     67),
    LV_PROPERTY_ID(OBJ, EXT_DRAW_SIZE,              LV_PROPERTY_TYPE_INT,       68),
    LV_PROPERTY_ID(OBJ, EVENT_COUNT,                LV_PROPERTY_TYPE_INT,       69),
    LV_PROPERTY_ID(OBJ, SCREEN,                     LV_PROPERTY_TYPE_OBJ,       70),
    LV_PROPERTY_ID(OBJ, DISPLAY,                    LV_PROPERTY_TYPE_POINTER,   71),
    LV_PROPERTY_ID(OBJ, CHILD_COUNT,                LV_PROPERTY_TYPE_INT,       72),
    LV_PROPERTY_ID(OBJ, INDEX,                      LV_PROPERTY_TYPE_INT,       73),

    /*Dedicated boolean properties backing the per-flag setters/getters.
     *The OBJ_FLAG_* properties above are kept for backward compatibility.*/
    LV_PROPERTY_ID(OBJ, HIDDEN,                     LV_PROPERTY_TYPE_BOOL,      74),
    LV_PROPERTY_ID(OBJ, CLICKABLE,                  LV_PROPERTY_TYPE_BOOL,      75),
    LV_PROPERTY_ID(OBJ, CLICK_FOCUSABLE,            LV_PROPERTY_TYPE_BOOL,      76),
    LV_PROPERTY_ID(OBJ, CHECKABLE,                  LV_PROPERTY_TYPE_BOOL,      77),
    LV_PROPERTY_ID(OBJ, SCROLLABLE,                 LV_PROPERTY_TYPE_BOOL,      78),
    LV_PROPERTY_ID(OBJ, SCROLL_ELASTIC,             LV_PROPERTY_TYPE_BOOL,      79),
    LV_PROPERTY_ID(OBJ, SCROLL_MOMENTUM,            LV_PROPERTY_TYPE_BOOL,      80),
    LV_PROPERTY_ID(OBJ, SCROLL_ONE,                 LV_PROPERTY_TYPE_BOOL,      81),
    LV_PROPERTY_ID(OBJ, SCROLL_CHAIN_HOR,           LV_PROPERTY_TYPE_BOOL,      82),
    LV_PROPERTY_ID(OBJ, SCROLL_CHAIN_VER,           LV_PROPERTY_TYPE_BOOL,      83),
    LV_PROPERTY_ID(OBJ, SCROLL_ON_FOCUS,            LV_PROPERTY_TYPE_BOOL,      84),
    LV_PROPERTY_ID(OBJ, SCROLL_WITH_ARROW,          LV_PROPERTY_TYPE_BOOL,      85),
    LV_PROPERTY_ID(OBJ, SNAPPABLE,                  LV_PROPERTY_TYPE_BOOL,      86),
    LV_PROPERTY_ID(OBJ, PRESS_LOCK,                 LV_PROPERTY_TYPE_BOOL,      87),
    LV_PROPERTY_ID(OBJ, EVENT_BUBBLE,               LV_PROPERTY_TYPE_BOOL,      88),
    LV_PROPERTY_ID(OBJ, GESTURE_BUBBLE,             LV_PROPERTY_TYPE_BOOL,      89),
    LV_PROPERTY_ID(OBJ, ADV_HITTEST,                LV_PROPERTY_TYPE_BOOL,      90),
    LV_PROPERTY_ID(OBJ, IGNORE_LAYOUT,              LV_PROPERTY_TYPE_BOOL,      91),
    LV_PROPERTY_ID(OBJ, FLOATING,                   LV_PROPERTY_TYPE_BOOL,      92),
    LV_PROPERTY_ID(OBJ, SEND_DRAW_TASK_EVENTS,      LV_PROPERTY_TYPE_BOOL,      93),
    LV_PROPERTY_ID(OBJ, OVERFLOW_VISIBLE,           LV_PROPERTY_TYPE_BOOL,      94),
    LV_PROPERTY_ID(OBJ, EVENT_TRICKLE,              LV_PROPERTY_TYPE_BOOL,      95),
    LV_PROPERTY_ID(OBJ, STATE_TRICKLE,              LV_PROPERTY_TYPE_BOOL,      96),
    LV_PROPERTY_ID(OBJ, FLEX_IN_NEW_TRACK,          LV_PROPERTY_TYPE_BOOL,      97),

    LV_PROPERTY_OBJ_END,
};
#endif

/**
 * Make the base object's class publicly available.
 */
LV_ATTRIBUTE_EXTERN_DATA extern const lv_obj_class_t lv_obj_class;

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**
 * Create a base object (a rectangle)
 * @param parent    pointer to a parent widget @nullable. When NULL, the widget
 *                  is created as a screen on the default display.
 * @return          pointer to the new object
 */
lv_obj_t * lv_obj_create(lv_obj_t * parent);

/*=====================
 * Setter functions
 *====================*/

/**
 * Set one or more flags
 * @param obj   pointer to an object
 * @param f     OR-ed values from `lv_obj_flag_t` to set.
 * @deprecated  Use the dedicated per-flag setter instead, e.g. `lv_obj_set_hidden(obj, true)`.
 */
LV_DEPRECATED("Use the dedicated lv_obj_set_<flag>() setters instead, e.g. lv_obj_set_hidden(obj, true).")
void lv_obj_add_flag(lv_obj_t * obj, lv_obj_flag_t f);

/**
 * Remove one or more flags
 * @param obj   pointer to an object
 * @param f     OR-ed values from `lv_obj_flag_t` to clear.
 * @deprecated  Use the dedicated per-flag setter instead, e.g. `lv_obj_set_hidden(obj, false)`.
 */
LV_DEPRECATED("Use the dedicated lv_obj_set_<flag>() setters instead, e.g. lv_obj_set_hidden(obj, false).")
void lv_obj_remove_flag(lv_obj_t * obj, lv_obj_flag_t f);

/**
 * Set add or remove one or more flags.
 * @param obj   pointer to an object
 * @param f     OR-ed values from `lv_obj_flag_t` to update.
 * @param v     true: add the flags; false: remove the flags
 * @deprecated  Use the dedicated per-flag setter instead, e.g. `lv_obj_set_hidden(obj, en)`.
 */
LV_DEPRECATED("Use the dedicated lv_obj_set_<flag>() setters instead, e.g. lv_obj_set_hidden(obj, en).")
void lv_obj_set_flag(lv_obj_t * obj, lv_obj_flag_t f, bool v);

/** Make the object hidden. (Like it wasn't there at all)
 * @param obj     pointer to a widget
 * @param en      enable or disable the hidden property
 */
void lv_obj_set_hidden(lv_obj_t * obj, bool en);

/** Make the object clickable by the input devices
 * @param obj     pointer to a widget
 * @param en      enable or disable the clickable property
 */
void lv_obj_set_clickable(lv_obj_t * obj, bool en);

/** Add focused state to the object when clicked
 * @param obj     pointer to a widget
 * @param en      enable or disable the click focusable property
 */
void lv_obj_set_click_focusable(lv_obj_t * obj, bool en);

/** Toggle checked state when the object is clicked
 * @param obj     pointer to a widget
 * @param en      enable or disable the checkable property
 */
void lv_obj_set_checkable(lv_obj_t * obj, bool en);

/** Make the object scrollable
 * @param obj     pointer to a widget
 * @param en      enable or disable the scrollable property
 */
void lv_obj_set_scrollable(lv_obj_t * obj, bool en);

/** Allow scrolling inside but with slower speed
 * @param obj     pointer to a widget
 * @param en      enable or disable the scroll elastic property
 */
void lv_obj_set_scroll_elastic(lv_obj_t * obj, bool en);

/** Make the object scroll further when "thrown"
 * @param obj     pointer to a widget
 * @param en      enable or disable the scroll momentum property
 */
void lv_obj_set_scroll_momentum(lv_obj_t * obj, bool en);

/** Allow scrolling only one snappable child
 * @param obj     pointer to a widget
 * @param en      enable or disable the scroll one property
 */
void lv_obj_set_scroll_one(lv_obj_t * obj, bool en);

/** Allow propagating the scrolling in any directions to a parent
 * @param obj     pointer to a widget
 * @param en      enable or disable scroll chaining
 */
void lv_obj_set_scroll_chain(lv_obj_t * obj, bool en);

/** Allow propagating the horizontal scroll to a parent
 * @param obj     pointer to a widget
 * @param en      enable or disable horizontal scroll chaining
 */
void lv_obj_set_scroll_chain_hor(lv_obj_t * obj, bool en);

/** Allow propagating the vertical scroll to a parent
 * @param obj     pointer to a widget
 * @param en      enable or disable vertical scroll chaining
 */
void lv_obj_set_scroll_chain_ver(lv_obj_t * obj, bool en);

/** Automatically scroll object to make it visible when focused
 * @param obj     pointer to a widget
 * @param en      enable or disable scroll on focus
 */
void lv_obj_set_scroll_on_focus(lv_obj_t * obj, bool en);

/** Allow scrolling the focused object with arrow keys
 * @param obj     pointer to a widget
 * @param en      enable or disable scroll with arrow keys
 */
void lv_obj_set_scroll_with_arrow(lv_obj_t * obj, bool en);

/** Allow snapping to this object if scroll snap is enabled on the parent
 * @param obj     pointer to a widget
 * @param en      enable or disable the snappable property
 */
void lv_obj_set_snappable(lv_obj_t * obj, bool en);

/** Keep the object pressed even if the press slid from the object
 * @param obj     pointer to a widget
 * @param en      enable or disable the press lock property
 */
void lv_obj_set_press_lock(lv_obj_t * obj, bool en);

/** Propagate the events to the parent too
 * @param obj     pointer to a widget
 * @param en      enable or disable event bubbling
 */
void lv_obj_set_event_bubble(lv_obj_t * obj, bool en);

/** Propagate the gestures to the parent
 * @param obj     pointer to a widget
 * @param en      enable or disable gesture bubbling
 */
void lv_obj_set_gesture_bubble(lv_obj_t * obj, bool en);

/** Allow performing more accurate hit test
 * @param obj     pointer to a widget
 * @param en      enable or disable advanced hit testing
 */
void lv_obj_set_adv_hittest(lv_obj_t * obj, bool en);

/** Make the object not positioned by layouts
 * @param obj     pointer to a widget
 * @param en      enable or disable ignoring layout
 */
void lv_obj_set_ignore_layout(lv_obj_t * obj, bool en);

/** Do not scroll the object when the parent scrolls and ignore layout
 * @param obj     pointer to a widget
 * @param en      enable or disable floating mode
 */
void lv_obj_set_floating(lv_obj_t * obj, bool en);

/** Send LV_EVENT_DRAW_TASK_ADDED events
 * @param obj     pointer to a widget
 * @param en      enable or disable draw task events
 */
void lv_obj_set_send_draw_task_events(lv_obj_t * obj, bool en);

/** Do not clip the children to the parent's extended draw size
 * @param obj     pointer to a widget
 * @param en      enable or disable overflow visibility
 */
void lv_obj_set_overflow_visible(lv_obj_t * obj, bool en);

/** Propagate the events to the children too
 * @param obj     pointer to a widget
 * @param en      enable or disable event trickling
 */
void lv_obj_set_event_trickle(lv_obj_t * obj, bool en);

/** Propagate the states to the children too
 * @param obj     pointer to a widget
 * @param en      enable or disable state trickling
 */
void lv_obj_set_state_trickle(lv_obj_t * obj, bool en);

/** Allow only one RADIO_BUTTON sibling to be checked
 * @param obj     pointer to a widget
 * @param en      enable or disable radio button behavior
 */
void lv_obj_set_radio_button(lv_obj_t * obj, bool en);

/** Start a new flex track on this item
 * @param obj     pointer to a widget
 * @param en      enable or disable new flex track
 */
void lv_obj_set_flex_in_new_track(lv_obj_t * obj, bool en);

/**
 * Add one or more states to the object. The other state bits will remain unchanged.
 * If specified in the styles, transition animation will be started from the previous state to the current.
 * @param obj       pointer to an object
 * @param state     the states to add. E.g `LV_STATE_PRESSED | LV_STATE_FOCUSED`
 */
void lv_obj_add_state(lv_obj_t * obj, lv_state_t state);

/**
 * Remove one or more states to the object. The other state bits will remain unchanged.
 * If specified in the styles, transition animation will be started from the previous state to the current.
 * @param obj       pointer to an object
 * @param state     the states to add. E.g `LV_STATE_PRESSED | LV_STATE_FOCUSED`
 */
void lv_obj_remove_state(lv_obj_t * obj, lv_state_t state);

/**
 * Add or remove one or more states to the object. The other state bits will remain unchanged.
 * @param obj       pointer to an object
 * @param state     the states to add. E.g `LV_STATE_PRESSED | LV_STATE_FOCUSED`
 * @param v         true: add the states; false: remove the states
 */
void lv_obj_set_state(lv_obj_t * obj, lv_state_t state, bool v);

/** Add or remove `LV_STATE_ALT`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_alt(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_CHECKED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_checked(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_FOCUSED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_focused(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_FOCUS_KEY`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_focus_key(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_EDITED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_edited(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_HOVERED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_hovered(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_PRESSED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_pressed(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_SCROLLED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_scrolled(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_DISABLED`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_disabled(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_USER_1`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_state_user_1(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_USER_2`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_state_user_2(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_USER_3`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_state_user_3(lv_obj_t * obj, bool en);

/** Add or remove `LV_STATE_USER_4`. The other states remain unchanged.
 * @param obj     pointer to a widget
 * @param en      true: add the state; false: remove the state
 */
void lv_obj_set_state_user_4(lv_obj_t * obj, bool en);

/**
 * Set the user_data field of the object
 * @param obj   pointer to an object
 * @param user_data   pointer to the new user_data. @nullable
 */
void lv_obj_set_user_data(lv_obj_t * obj, void * user_data);

/**
 * Set one of the 4 flags available for the user
 * @param obj   pointer to an object
 * @param bit   the index of the bit (0..3)
 * @param v     the value of the bit, true or false
 */
void lv_obj_set_user_flag(lv_obj_t * obj, uint32_t bit, bool v);

/*=======================
 * Getter functions
 *======================*/

/**
 * Check if a given flag or all the given flags are set on an object.
 * @param obj   pointer to an object
 * @param f     the flag(s) to check (OR-ed values can be used)
 * @return      true: all flags are set; false: not all flags are set
 * @deprecated  Use the dedicated per-flag setter instead, e.g. `lv_obj_is_hidden(obj)`.
 */
LV_DEPRECATED("Use the dedicated lv_obj_is_<flag>() functions instead, e.g. lv_obj_is_hidden(obj).")
bool lv_obj_has_flag(const lv_obj_t * obj, lv_obj_flag_t f);

/**
 * Check if a given flag or any of the flags are set on an object.
 * @param obj   pointer to an object
 * @param f     the flag(s) to check (OR-ed values can be used)
 * @return      true: at least one flag is set; false: none of the flags are set
 * @deprecated  Use the dedicated per-flag setter instead, e.g. `lv_obj_set_hidden(obj)`.
 */
LV_DEPRECATED("Use the dedicated lv_obj_is_<flag>() functions instead, e.g. lv_obj_is_hidden(obj).")
bool lv_obj_has_flag_any(const lv_obj_t * obj, lv_obj_flag_t f);

/** Get whether the object is hidden
 * @param obj     pointer to a widget
 * @return        true if the object is hidden, false otherwise
 */
bool lv_obj_is_hidden(const lv_obj_t * obj);

/** Get whether the object is clickable by input devices
 * @param obj     pointer to a widget
 * @return        true if the object is clickable
 */
bool lv_obj_is_clickable(const lv_obj_t * obj);

/** Get whether the object gets focused when clicked
 * @param obj     pointer to a widget
 * @return        true if click focusable is enabled
 */
bool lv_obj_is_click_focusable(const lv_obj_t * obj);

/** Get whether the object toggles checked state when clicked
 * @param obj     pointer to a widget
 * @return        true if the object is checkable
 */
bool lv_obj_is_checkable(const lv_obj_t * obj);

/** Get whether the object is scrollable
 * @param obj     pointer to a widget
 * @return        true if the object is scrollable
 */
bool lv_obj_is_scrollable(const lv_obj_t * obj);

/** Get whether elastic scrolling is enabled
 * @param obj     pointer to a widget
 * @return        true if scroll elastic is enabled
 */
bool lv_obj_is_scroll_elastic(const lv_obj_t * obj);

/** Get whether scroll momentum is enabled
 * @param obj     pointer to a widget
 * @return        true if scroll momentum is enabled
 */
bool lv_obj_is_scroll_momentum(const lv_obj_t * obj);

/** Get whether only one snappable child can be scrolled
 * @param obj     pointer to a widget
 * @return        true if scroll one is enabled
 */
bool lv_obj_is_scroll_one(const lv_obj_t * obj);

/** Get whether horizontal scroll chaining is enabled
 * @param obj     pointer to a widget
 * @return        true if horizontal scroll chaining is enabled
 */
bool lv_obj_is_scroll_chain_hor(const lv_obj_t * obj);

/** Get whether vertical scroll chaining is enabled
 * @param obj     pointer to a widget
 * @return        true if vertical scroll chaining is enabled
 */
bool lv_obj_is_scroll_chain_ver(const lv_obj_t * obj);

/** Get whether the object auto-scrolls into view when focused
 * @param obj     pointer to a widget
 * @return        true if scroll on focus is enabled
 */
bool lv_obj_is_scroll_on_focus(const lv_obj_t * obj);

/** Get whether the focused object can be scrolled with arrow keys
 * @param obj     pointer to a widget
 * @return        true if scroll with arrow keys is enabled
 */
bool lv_obj_is_scroll_with_arrow(const lv_obj_t * obj);

/** Get whether the object is snappable by a scrolling parent
 * @param obj     pointer to a widget
 * @return        true if the object is snappable
 */
bool lv_obj_is_snappable(const lv_obj_t * obj);

/** Get whether press lock is enabled
 * @param obj     pointer to a widget
 * @return        true if press lock is enabled
 */
bool lv_obj_is_press_lock(const lv_obj_t * obj);

/** Get whether events bubble to the parent
 * @param obj     pointer to a widget
 * @return        true if event bubbling is enabled
 */
bool lv_obj_is_event_bubble(const lv_obj_t * obj);

/** Get whether gestures bubble to the parent
 * @param obj     pointer to a widget
 * @return        true if gesture bubbling is enabled
 */
bool lv_obj_is_gesture_bubble(const lv_obj_t * obj);

/** Get whether advanced hit testing is enabled
 * @param obj     pointer to a widget
 * @return        true if advanced hit testing is enabled
 */
bool lv_obj_is_adv_hittest(const lv_obj_t * obj);

/** Get whether the object ignores layout positioning
 * @param obj     pointer to a widget
 * @return        true if ignore layout is enabled
 */
bool lv_obj_is_ignore_layout(const lv_obj_t * obj);

/** Get whether the object is floating
 * @param obj     pointer to a widget
 * @return        true if floating mode is enabled
 */
bool lv_obj_is_floating(const lv_obj_t * obj);

/** Get whether draw task events are sent
 * @param obj     pointer to a widget
 * @return        true if draw task events are enabled
 */
bool lv_obj_is_send_draw_task_events(const lv_obj_t * obj);

/** Get whether overflow is visible outside the parent
 * @param obj     pointer to a widget
 * @return        true if overflow is visible
 */
bool lv_obj_is_overflow_visible(const lv_obj_t * obj);

/** Get whether events trickle to the children
 * @param obj     pointer to a widget
 * @return        true if event trickling is enabled
 */
bool lv_obj_is_event_trickle(const lv_obj_t * obj);

/** Get whether states trickle to the children
 * @param obj     pointer to a widget
 * @return        true if state trickling is enabled
 */
bool lv_obj_is_state_trickle(const lv_obj_t * obj);

/** Get whether the object is a radio button
 * @param obj     pointer to a widget
 * @return        true if radio button behavior is enabled
 */
bool lv_obj_is_radio_button(const lv_obj_t * obj);

/**
 * Get whether the widget should be placed in a new flex track
 * @param obj   pointer to a widget
 * @return      true if flex in new track is enabled
 */
bool lv_obj_is_flex_in_new_track(const lv_obj_t * obj);

/**
 * Get the state of an object
 * @param obj   pointer to an object
 * @return      the state (OR-ed values from `lv_state_t`)
 */
lv_state_t lv_obj_get_state(const lv_obj_t * obj);

/**
 * Check if the object is in a given state or not.
 * @param obj       pointer to an object
 * @param state     a state or combination of states to check
 * @return          true: `obj` is in `state`; false: `obj` is not in `state`
 */
bool lv_obj_has_state(const lv_obj_t * obj, lv_state_t state);

/** Get whether the object is in `LV_STATE_ALT`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_alt(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_CHECKED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_checked(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_FOCUSED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_focused(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_FOCUS_KEY`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_focus_key(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_EDITED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_edited(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_HOVERED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_hovered(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_PRESSED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_pressed(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_SCROLLED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_scrolled(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_DISABLED`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_disabled(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_USER_1`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_state_user_1(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_USER_2`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_state_user_2(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_USER_3`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_state_user_3(const lv_obj_t * obj);

/** Get whether the object is in `LV_STATE_USER_4`
 * @param obj     pointer to a widget
 * @return        true if the state is set
 */
bool lv_obj_is_state_user_4(const lv_obj_t * obj);

/**
 * Get the group of the object
 * @param       obj pointer to an object
 * @return      the pointer to group of the object
 */
lv_group_t * lv_obj_get_group(const lv_obj_t * obj);

/**
 * Get the user_data field of the object
 * @param obj   pointer to an object
 * @return      the pointer to the user_data of the object
 */
void * lv_obj_get_user_data(lv_obj_t * obj);

/**
 * Get the value of one of the 4 flags available for the user
 * @param obj   pointer to an object
 * @param bit   the index of the bit (0..3)
 * @return      the value of the bit, true or false
 */
bool lv_obj_get_user_flag(lv_obj_t * obj, uint32_t bit);

/*=======================
 * Other functions
 *======================*/

/**
 * Check the type of obj.
 * @param obj       pointer to an object
 * @param class_p   a class to check (e.g. `lv_slider_class`)
 * @return          true: `class_p` is the `obj` class.
 */
bool lv_obj_check_type(const lv_obj_t * obj, const lv_obj_class_t * class_p);

/**
 * Check if any object has a given class (type).
 * It checks the ancestor classes too.
 * @param obj       pointer to an object
 * @param class_p   a class to check (e.g. `lv_slider_class`)
 * @return          true: `obj` has the given class
 */
bool lv_obj_has_class(const lv_obj_t * obj, const lv_obj_class_t * class_p);

/**
 * Get the class (type) of the object
 * @param obj   pointer to an object
 * @return      the class (type) of the object
 */
const lv_obj_class_t * lv_obj_get_class(const lv_obj_t * obj);

/**
 * Check if any object is still "alive".
 * @param obj       pointer to an object
 * @return          true: valid
 */
bool lv_obj_is_valid(const lv_obj_t * obj);

/**
 * Utility to set an object reference to NULL when it gets deleted.
 * The reference should be in a location that will not become invalid
 * during the object's lifetime, i.e. static or allocated.
 * @param obj_ptr   a pointer to a pointer to an object
 */
void lv_obj_null_on_delete(lv_obj_t ** obj_ptr);

/**
 * Attach a delete callback to an object.
 *
 * The registered callback will be automatically invoked with `user_data` as
 * its argument when the object is deleted, allowing associated resources to
 * be released or any other cleanup logic to be executed by the callback.
 *
 * This is a utility function that simplifies attaching an `LV_EVENT_DELETE`
 * event callback to `obj` and passing `user_data` to that callback when the
 * object is deleted.
 *
 * The `lv_delete_dsc_t` returned by this function is automatically released when
 * the object is deleted as well.
 *
 * @param obj       Pointer to the LVGL object to attach the delete callback to.
 * @param cb        The delete callback function to register.
 * @param user_data     User data pointer passed to `cb` when the object is deleted. @nullable
 *
 * @return      Pointer to the delete descriptor or NULL if the operation failed.
 */
lv_delete_dsc_t * lv_obj_add_delete_cb(lv_obj_t * obj, lv_delete_cb_t cb, void * user_data);

/**
 * Detach a delete callback from an object.
 *
 * Removes a delete descriptor previously created via @ref lv_obj_add_delete_cb
 *
 * @param dsc   Pointer to the delete descriptor. Passing NULL results in a no-op @nullable
 */
void lv_obj_remove_delete_cb(lv_delete_dsc_t * dsc);

/**
 * Add an event handler to a widget that will load a screen on a trigger.
 * @param obj           pointer to widget which should load the screen
 * @param trigger       an event code, e.g. `LV_EVENT_CLICKED`
 * @param screen        the screen to load (must be a valid widget)
 * @param anim_type     element of `lv_screen_load_anim_t` the screen load animation
 * @param duration      duration of the animation in milliseconds
 * @param delay         delay before the screen load in milliseconds
 */
void lv_obj_add_screen_load_event(lv_obj_t * obj, lv_event_code_t trigger, lv_obj_t * screen,
                                  lv_screen_load_anim_t anim_type, uint32_t duration, uint32_t delay);

/**
 * Add an event handler to a widget that will create a screen on a trigger.
 * The created screen will be deleted when it's unloaded
 * @param obj               pointer to widget which should load the screen
 * @param trigger           an event code, e.g. `LV_EVENT_CLICKED`
 * @param screen_create_cb  a callback to create the screen, e.g. `lv_obj_t * myscreen_create(void)`
 * @param anim_type         element of `lv_screen_load_anim_t` the screen load animation
 * @param duration          duration of the animation in milliseconds
 * @param delay             delay before the screen load in milliseconds
 */
void lv_obj_add_screen_create_event(lv_obj_t * obj, lv_event_code_t trigger, lv_screen_create_cb_t screen_create_cb,
                                    lv_screen_load_anim_t anim_type, uint32_t duration, uint32_t delay);


/**
 * Play a timeline animation on a trigger
 * @param obj               pointer to widget which should trigger playing the animation
 * @param trigger           an event code, e.g. `LV_EVENT_CLICKED`
 * @param at                pointer to an animation timeline
 * @param delay             wait time before starting the animation
 * @param reverse           true: play in reverse
 */
void lv_obj_add_play_timeline_event(lv_obj_t * obj, lv_event_code_t trigger, lv_anim_timeline_t * at, uint32_t delay,
                                    bool reverse);

#if LV_USE_OBJ_ID
/**
 * Set an id for an object.
 * @param obj   pointer to an object
 * @param id    the id of the object @nullable. When NULL any previous id is dropped.
 */
void lv_obj_set_id(lv_obj_t * obj, void * id);

/**
 * Get the id of an object.
 * @param obj   pointer to an object
 * @return      the id of the object
 */
void * lv_obj_get_id(const lv_obj_t * obj);

/**
 *
 * Get the child object by its id.
 * It will check children and grandchildren recursively.
 * Function `lv_obj_id_compare` is used to matched obj id with given id.
 *
 * @deprecated IDs are used only to print the widget trees. To find a widget use `lv_obj_find_by_name`
 *
 * @param obj       pointer to an object @nullable. When NULL the active screen is
 *                  searched.
 * @param id        the id of the child object
 * @return          pointer to the child object or NULL if not found
 */
LV_DEPRECATED("IDs are used only to print the widget trees. To find a widget use lv_obj_find_by_name")
lv_obj_t * lv_obj_find_by_id(const lv_obj_t * obj, const void * id);

/**
 * Assign id to object if not previously assigned.
 * This function gets called automatically when LV_OBJ_ID_AUTO_ASSIGN is enabled.
 *
 * Set `LV_USE_OBJ_ID_BUILTIN` to use the builtin method to generate object ID.
 * Otherwise, these functions including `lv_obj_[set|assign|free|stringify]_id` and
 * `lv_obj_id_compare`should be implemented externally.
 *
 * @param class_p   the class this obj belongs to. Note obj->class_p is the class currently being constructed.
 * @param obj   pointer to an object
 */
void lv_obj_assign_id(const lv_obj_class_t * class_p, lv_obj_t * obj);

/**
 * Free resources allocated by `lv_obj_assign_id` or `lv_obj_set_id`.
 * This function is also called automatically when object is deleted.
 * @param obj   pointer to an object
 */
void lv_obj_free_id(lv_obj_t * obj);

/**
 * Compare two obj id, return 0 if they are equal.
 *
 * Set `LV_USE_OBJ_ID_BUILTIN` to use the builtin method for compare.
 * Otherwise, it must be implemented externally.
 *
 * @param id1: the first id @nullable
 * @param id2: the second id @nullable
 * @return     0 if they are equal, non-zero otherwise.
 */
int lv_obj_id_compare(const void * id1, const void * id2);

/**
 * Format an object's id into a string.
 * @param obj   pointer to an object
 * @param buf   buffer to write the string into
 * @param len   length of the buffer
 */
const char * lv_obj_stringify_id(lv_obj_t * obj, char * buf, uint32_t len);

#if LV_USE_OBJ_ID_BUILTIN
/**
 * Free resources used by builtin ID generator.
 */
void lv_objid_builtin_destroy(void);
#endif

#endif /*LV_USE_OBJ_ID*/

/**********************
 *      MACROS
 **********************/

#if LV_USE_ASSERT_OBJ
/**
 * @deprecated Use `LV_CHECK_OBJ(obj, cls, return)` instead.
 *             `LV_ASSERT_OBJ` aborts on failure; `LV_CHECK_OBJ` logs a warning
 *             and executes the supplied action, which is safer in production.
 */
#define LV_ASSERT_OBJ(obj_p, obj_class)                                                                      \
    do {                                                                                                     \
        LV_DEPRECATED_MACRO_WARN("LV_ASSERT_OBJ is deprecated. Use LV_CHECK_OBJ instead.");                  \
        LV_ASSERT_INTERNAL(obj_p != NULL, "");                                                               \
        LV_ASSERT_INTERNAL(lv_obj_has_class(obj_p, obj_class) == true, "");                                  \
        LV_ASSERT_INTERNAL(lv_obj_is_valid(obj_p) == true, "");                                              \
    } while(0)
# else
/**
 * @deprecated Use `LV_CHECK_OBJ(obj, cls, return)` instead.
 */
#define LV_ASSERT_OBJ(obj_p, obj_class) \
    do { \
        LV_DEPRECATED_MACRO_WARN("LV_ASSERT_OBJ is deprecated. Use LV_CHECK_OBJ instead."); \
        LV_ASSERT_INTERNAL(obj_p, ""); \
    } while(0)
#endif

#if LV_USE_LOG && LV_LOG_TRACE_OBJ_CREATE
#  define LV_TRACE_OBJ_CREATE(...) LV_LOG_TRACE(__VA_ARGS__)
#else
#  define LV_TRACE_OBJ_CREATE(...)
#endif

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*LV_OBJ_H*/
