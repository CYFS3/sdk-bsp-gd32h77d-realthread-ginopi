/**
 * @file lv_assert.h
 *
 */

#ifndef LV_ASSERT_H
#define LV_ASSERT_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "../config/lv_conf_internal.h"
#include "../logging/lv_log.h"
#include "../stdlib/lv_mem.h"

/* LV_ASSERT_CUSTOM_INCLUDE (gated by LV_ASSERT_USE_CUSTOM_INCLUDE) is included
 * from lv_conf_internal.h, so the custom LV_ASSERT_HANDLER is already defined. */
#ifndef LV_ASSERT_HANDLER
#define LV_ASSERT_HANDLER while(1); /*halt by default*/
#endif

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**********************
 *      MACROS
 **********************/


#define LV_ASSERT_INTERNAL(expr, msg)                                                   \
    do {                                                                                \
        if(!(expr)) {                                                                   \
            LV_LOG_ERROR("Assertion `%s` failed." msg, #expr);                         \
            LV_ASSERT_HANDLER                                                           \
        }                                                                               \
    } while(0)

#define LV_ASSERT_FORMAT_INTERNAL(expr, format, ...)                                    \
    do {                                                                                \
        if(!(expr)) {                                                                   \
            LV_LOG_ERROR("Assertion `%s` failed." format, #expr, __VA_ARGS__);          \
            LV_ASSERT_HANDLER                                                           \
        }                                                                               \
    } while(0)

#if LV_USE_ASSERT

#define LV_ASSERT(expr) LV_ASSERT_INTERNAL(expr, "")
#define LV_ASSERT_MSG(expr, msg) LV_ASSERT_INTERNAL(expr, " " msg)
#define LV_ASSERT_FORMAT_MSG(expr, format, ...) LV_ASSERT_FORMAT_INTERNAL(expr, format, __VA_ARGS__)

#else

#define LV_ASSERT(expr)
#define LV_ASSERT_MSG(expr, msg)
#define LV_ASSERT_FORMAT_MSG(expr, format, ...)

#endif /* LV_USE_ASSERT */

/*-----------------
 * ASSERTS
 *-----------------*/

#if LV_USE_ASSERT_NULL
#   define LV_ASSERT_NULL(p) LV_ASSERT_INTERNAL(p != NULL, " NULL pointer");
#else
#   define LV_ASSERT_NULL(p)
#endif

#if LV_USE_ASSERT_MALLOC
#   define LV_ASSERT_MALLOC(p) LV_ASSERT_INTERNAL(p != NULL, " Out of memory");
#else
#   define LV_ASSERT_MALLOC(p)
#endif

#if LV_USE_ASSERT_MEM_INTEGRITY
#   define LV_ASSERT_MEM_INTEGRITY() LV_ASSERT_INTERNAL(lv_mem_test() == LV_RESULT_OK, " Memory integrity error");
#else
#   define LV_ASSERT_MEM_INTEGRITY()
#endif

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*LV_ASSERT_H*/
