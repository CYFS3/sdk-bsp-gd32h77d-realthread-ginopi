/**
 * @file lv_log.h
 *
 */

#ifndef LV_LOG_H
#define LV_LOG_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "../config/lv_conf_internal.h"

#include "../lv_types.h"

/*********************
 *      DEFINES
 *********************/

/*Possible log level. For compatibility declare it independently from `LV_USE_LOG`*/
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_TRACE);
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_INFO);
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_WARN);
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_ERROR);
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_USER);
LV_EXPORT_CONST_INT(LV_LOG_LEVEL_NONE);

typedef int8_t lv_log_level_t;

#if LV_USE_LOG

#if LV_LOG_USE_FILE_LINE
#define LV_LOG_FILE __FILE__
#define LV_LOG_LINE __LINE__
#else
#define LV_LOG_FILE NULL
#define LV_LOG_LINE 0
#endif

/**********************
 *      TYPEDEFS
 **********************/

/**
 * Log print function. Receives a string buffer to print".
 */
typedef void (*lv_log_print_g_cb_t)(lv_log_level_t level, const char * buf);

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**
 * Register custom print/write function to call when a log is added.
 * It can format its "File path", "Line number" and "Description" as required
 * and send the formatted log message to a console or serial port.
 * @param           print_cb a function pointer to print a log
 */
void lv_log_register_print_cb(lv_log_print_g_cb_t print_cb);

/**
 * Print a log message via `printf` if enabled with `LV_LOG_PRINTF` in `lv_conf.h`
 * and/or a print callback if registered with `lv_log_register_print_cb`
 * @param format    printf-like format string
 * @param ...       parameters for `format`
 */
void lv_log(const char * format, ...) LV_FORMAT_ATTRIBUTE(1, 2);

/**
 * Add a log
 * @param level     the level of log. (From `lv_log_level_t` enum)
 * @param file      name of the file when the log added
 * @param line      line number in the source code where the log added
 * @param func      name of the function when the log added
 * @param format    printf-like format string
 * @param ...       parameters for `format`
 */
void lv_log_add(lv_log_level_t level, const char * file, int line,
                const char * func, const char * format, ...) LV_FORMAT_ATTRIBUTE(5, 6);

/**********************
 *      MACROS
 **********************/
#ifndef LV_LOG_TRACE
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_TRACE
#    define LV_LOG_TRACE(...) lv_log_add(LV_LOG_LEVEL_TRACE, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__)
#  else
#    define LV_LOG_TRACE(...) do {}while(0)
#  endif
#endif

#ifndef LV_LOG_INFO
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_INFO
#    define LV_LOG_INFO(...) lv_log_add(LV_LOG_LEVEL_INFO, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__)
#  else
#    define LV_LOG_INFO(...) do {}while(0)
#  endif
#endif

#ifndef LV_LOG_WARN
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_WARN
#    define LV_LOG_WARN(...) lv_log_add(LV_LOG_LEVEL_WARN, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__)
#  else
#    define LV_LOG_WARN(...) do {}while(0)
#  endif
#endif


#ifndef LV_LOG_WARN_ONCE
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_WARN
#    define LV_LOG_WARN_ONCE(...) do { \
        static int warned = 0; \
        if(!warned) { \
            warned = 1; \
            lv_log_add(LV_LOG_LEVEL_WARN, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__); \
        } \
    } while(0)
#  else
#    define LV_LOG_WARN_ONCE(...) do {}while(0)
#  endif
#endif

#ifndef LV_LOG_DEPRECATED
#define LV_LOG_DEPRECATED(msg) LV_LOG_WARN_ONCE("Deprecated: " msg)
#endif

#ifndef LV_LOG_ERROR
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_ERROR
#    define LV_LOG_ERROR(...) lv_log_add(LV_LOG_LEVEL_ERROR, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__)
#  else
#    define LV_LOG_ERROR(...) do {}while(0)
#  endif
#endif

#ifndef LV_LOG_USER
#  if LV_LOG_LEVEL <= LV_LOG_LEVEL_USER
#    define LV_LOG_USER(...) lv_log_add(LV_LOG_LEVEL_USER, LV_LOG_FILE, LV_LOG_LINE, __func__, __VA_ARGS__)
#  else
#    define LV_LOG_USER(...) do {}while(0)
#  endif
#endif

#ifndef LV_LOG
#  if LV_LOG_LEVEL < LV_LOG_LEVEL_NONE
#    define LV_LOG(...) lv_log(__VA_ARGS__)
#  else
#    define LV_LOG(...) do {} while(0)
#  endif
#endif

#else /*LV_USE_LOG*/

/* When LV_USE_LOG is 0 all logging macros expand to no-ops.
 * This also suppresses any log output from LV_CHECK_ARG (and similar check
 * macros such as LV_CHECK_OBJ) regardless of LV_CHECK_ARG_LOG_MODE. */
#define lv_log_add(level, file, line, ...)
#define LV_LOG_TRACE(...) do {}while(0)
#define LV_LOG_INFO(...) do {}while(0)
#define LV_LOG_WARN(...) do {}while(0)
#define LV_LOG_WARN_ONCE(...) do {}while(0)
#define LV_LOG_ERROR(...) do {}while(0)
#define LV_LOG_USER(...) do {}while(0)
#define LV_LOG(...) do {}while(0)

#define LV_LOG_DEPRECATED(_) do {}while(0)

#endif /*LV_USE_LOG*/

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif /*LV_LOG_H*/
