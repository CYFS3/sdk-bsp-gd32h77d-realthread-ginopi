/**
 * @file lv_version.h
 * The current version of LVGL
 */

#ifndef LV_VERSION_H
#define LV_VERSION_H

#define LVGL_VERSION_MAJOR 9
#define LVGL_VERSION_MINOR 6
#define LVGL_VERSION_PATCH 0
#define LVGL_VERSION_INFO "dev"

#endif /* LV_VERSION_H */
